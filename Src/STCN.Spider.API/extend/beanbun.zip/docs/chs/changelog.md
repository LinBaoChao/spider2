## [版本 1.0.3](https://github.com/kiddyuchina/Beanbun/releases/tag/1.0.3) (2017-4-27)

- 修改数据库类bug

## [版本 1.0.2](https://github.com/kiddyuchina/Beanbun/releases/tag/1.0.2) (2017-4-27)

- 内存队列增加布隆过滤器算法记录已爬取网页，并默认使用布隆过滤器
- 数据库操作类更改为基于 Medoo，支持多种数据库类型，并更改了使用方式
- 把官网文档文件加入库

## [版本 1.0.1](https://github.com/kiddyuchina/Beanbun/releases/tag/1.0.1) (2017-4-16)

- 增加框架自带队列默认队列上限
- 更新自定义队列、自定义下载器设置方式
- 更新 README.md 文件
- 移除 imangazaliev/didom 依赖
- 修正 mysql 连接BUG

## [版本 1.0.0](https://github.com/kiddyuchina/Beanbun/releases/tag/1.0.0) (2017-4-13)

- 初版发布
