<?php
namespace Beanbun\Exception;

class BeanbunException extends \Exception
{
	
}
